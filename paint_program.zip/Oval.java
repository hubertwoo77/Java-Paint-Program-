/**
* Creates ovals
*
* @author Hubert Woo
* @version July 4 2022
*/
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.GradientPaint;
public class Oval extends FillableShape{
    private static int numOvals;
    //Constructor for Oval class
    public Oval( int x1, int y1, int x2, int y2, Color color,  boolean gradient, boolean filled, Color gradientColor1, Color gradientColor2){
        super(x1,y1,x2,y2,color, gradient, filled, gradientColor1, gradientColor2);
        numOvals++;
    }

    //Draw method for ovals
    public void draw( Graphics g){
        //In each gradient / non-gradient case, it also checks whetehr the shape should be filled or not
        if( getGradient() == true){
            //Creates a gradient pattern
            Graphics2D gradientTime = (Graphics2D)g;
            GradientPaint twoColors = new GradientPaint( (float) getX1(), (float) getY1(), getGradientColor1(), (float) getX2(), (float) getY2(), getGradientColor2());
            gradientTime.setPaint( twoColors);
            if(getFilled() == true){
                gradientTime.fillOval(getUpperLeftX(),getUpperLeftY(),getWidth(),getHeight());
            }
            else{
                gradientTime.drawOval(getUpperLeftX(),getUpperLeftY(),getWidth(),getHeight());
            }  
        }
        else{
            g.setColor( getColor());
            //Normal Oval
            if(getFilled() == true){
                g.fillOval(getUpperLeftX(),getUpperLeftY(),getWidth(),getHeight());
            }
            else{
                g.drawOval(getUpperLeftX(),getUpperLeftY(),getWidth(),getHeight());
            }
        } 
    }

    //Returns the number of ovals drawn
    public static int getNumOvals(){
        return numOvals;
    }
}