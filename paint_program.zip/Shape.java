/**
* Parent class for all drawable shapes in the program
*
* @author Hubert Woo
* @version July 4 2022
*/
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.GradientPaint;
abstract class Shape{
    private int x1;
    private int x2;
    private int y1;
    private int y2;
    private Color color; 
    private boolean gradient;
    private Color gradientColor1;
    private Color gradientColor2;

    //Constructor for shape class
    public Shape( int x1, int y1, int x2, int y2, Color color, boolean gradient, Color gradientColor1, Color gradientColor2){
       this.x1 = x1;
       this.y1 = y1;
       this.x2 = x2;
       this.y2 = y2;
       this.color = color;
       this.gradient = gradient;
       this.gradientColor1 = gradientColor1;
       this.gradientColor2 = gradientColor2;
    }

    //Public accessor for x1
    public int getX1(){
        return x1;
    }
    //Public accessor for x2
    public int getX2(){
        return x2;
    }
    //Public accessor for y1
    public int getY1(){
        return y1;
    }
    //Public accessor for y2
    public int getY2(){
        return y2;
    }
    //Public accessor for the color of the shape
    public Color getColor(){
        return color;
    }
    //Public mutator for x1
    public void setX1( int newValue){
        x1 = newValue;
    }
    //Public mutator for y1
    public void setY1( int newValue){
        y1 = newValue;
    }
    //Public mutator for x2
    public void setX2( int newValue){
        x2 = newValue;
    }
    //Public mutator for y2
    public void setY2( int newValue){
        y2 = newValue;
    }
    //Public mutator for shape color
    public void setColor( Color color){
        this.color = color;
    }
    //Public accessor for whether the shape should be normal or have a gradient
    public boolean getGradient(){
        return gradient;
    }
    //Public accessor for the first color in the gradient
    public Color getGradientColor1(){
        return gradientColor1;
    }
    //Public accessor for the second color in the gradient
    public Color getGradientColor2(){
        return gradientColor2;
    }
    //Abstract method for children classes to override
    abstract void draw( Graphics g);  
}