/**
* A blank canvas given to the user with an array of tools used to draw on the canvas 
*
* @author Hubert Woo
* @version July 4 2022
*/
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;

/**
* Mainline logic for the program
*/
public class PaintProgram {
    public static void main( String[] args ) {
        Options appWindow = new Options( "Hubert's Paint Program" );
               
                          
        appWindow.setSize( 320, 320 );
        appWindow.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        appWindow.setVisible( true );
    }    
}
