/**
* Provides the user with settings and options for drawing in the paint program
*
* @author Hubert Woo
* @version July 4 2022
*/
import java.awt.Color;
import javax.swing.JFrame;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import javax.swing.JColorChooser;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.colorchooser.AbstractColorChooserPanel;
import javax.swing.plaf.ColorChooserUI;
import java.util.ArrayList;

public class Options extends JFrame{
    private JButton colorChooser;
    private JTextField flledChoice; 
    private JCheckBox wantFilled;
    private String[] shapeOptions = { "Rectangle", "Oval", "Line", "Free Draw"};
    private JComboBox<String> shapeChooser;
    private boolean filled = false;
    private boolean isLine;
    private Color color = Color.LIGHT_GRAY;
    private DrawPanel mainPanel;
    private Color shapeColor;
    private JColorChooser moreColors;

    //undo, redo, clear buttons 
    private JButton undo;
    private JButton redo;
    private JButton clear;

    //gradient buttons
    private JButton gradient1;
    private JButton gradient2;
    private Color colorGradient1;
    private Color colorGradient2;
    private JColorChooser colorChoice1;
    private JColorChooser colorChoice2;
    private JCheckBox wantGradient;
    private boolean gradient = false;

    //Constructor for Options, creates the window and displays the canvas, mouse coordinates, and settings
    public Options( String name ){
        super(name);
        JLabel statusLabel = new JLabel();
        add( statusLabel, BorderLayout.SOUTH );
        // Put DrawPanel in CENTER and pass reference to statusLabel for updates
        mainPanel = new DrawPanel( statusLabel );
        add( mainPanel, BorderLayout.CENTER );        
        JPanel displayOptions = new JPanel();
        displayOptions.setLayout( new GridLayout( 1, 20 ) );
        //Allow room for any extra settings that may be added

        //choosing color
        moreColors = new JColorChooser( Color.LIGHT_GRAY);
        colorChooser = new JButton("Change Color");
        
        ChangeListener colorChoiceListener = new ColorComboBoxListener();
        moreColors.getSelectionModel().addChangeListener( colorChoiceListener );

        ActionListener changeColor = new ColorChangeButton();
        colorChooser.addActionListener( changeColor);
        displayOptions.add( colorChooser);

        //Checkbox to say if you want shapes filled or not
        wantFilled = new JCheckBox("Filled");
        ItemListener filledBoxListener = new CheckBoxListener();
        wantFilled.addItemListener ( filledBoxListener); 
        displayOptions.add( wantFilled);
        
        //choosing shape 
        shapeChooser = new JComboBox<String>( shapeOptions ); 
        ItemListener shapeChoice = new ChooseShapeListener();
        shapeChooser.addItemListener( shapeChoice);
        displayOptions.add( shapeChooser);

        //clear button
        clear = new JButton("Clear");
        ActionListener wantClear = new ClearCanvas();
        clear.addActionListener ( wantClear);
        displayOptions.add( clear);
        
        //undo button
        undo = new JButton("Undo");
        ActionListener wantUndo = new UndoShape();
        undo.addActionListener( wantUndo);
        displayOptions.add( undo);

        //redo button 
        redo = new JButton("Redo");
        ActionListener wantRedo = new RedoShape();
        redo.addActionListener( wantRedo);
        displayOptions.add( redo );

        //gradient
        gradient1 = new JButton("Gradient Color 1");
        gradient2 = new JButton("Gradient Color 2");
        gradient1.addActionListener(changeColor);
        gradient2.addActionListener(changeColor);

        colorChoice1 = new JColorChooser( Color.LIGHT_GRAY);
        colorChoice2 = new JColorChooser( Color.LIGHT_GRAY);
        ChangeListener gradientChanger1 = new GradientColor1();
        ChangeListener gradientChanger2 = new GradientColor2();
        colorChoice1.getSelectionModel().addChangeListener( gradientChanger1 );
        colorChoice2.getSelectionModel().addChangeListener( gradientChanger2 );

        wantGradient = new JCheckBox("Gradient");
        wantGradient.addItemListener ( filledBoxListener); 
        displayOptions.add( wantGradient);
        displayOptions.add( gradient1 );
        displayOptions.add( gradient2 );

        add(displayOptions, BorderLayout.NORTH);
    }

    //Listener class for non gradient JColorChooser color panel
    class ColorComboBoxListener implements ChangeListener{
        @Override 
        public void stateChanged( ChangeEvent e ) {
            DrawPanel.importColor(moreColors.getColor());
            
        }
    }

    //Listener class for the first color selected in  gradiant JColorChooser color panel
    class GradientColor1 implements ChangeListener{
        @Override 
        public void stateChanged( ChangeEvent e ) {
            DrawPanel.importColorGradient1(colorChoice1.getColor());
            
        }
    }
    //Listener class for the second color selected in  gradiant JColorChooser color panel
    class GradientColor2 implements ChangeListener{
        @Override 
        public void stateChanged( ChangeEvent e ) {
            DrawPanel.importColorGradient2(colorChoice2.getColor());        
        }
    }

    //Displays a specific JColorChooser panel depending on which button is pressed
    class ColorChangeButton implements ActionListener{
        @Override 
        public void actionPerformed( ActionEvent e ) {
            //Used for three JColorChooser objects, one for non gradient drawings and two for gradient drawings
            if(e.getSource() == colorChooser){
                JOptionPane.showMessageDialog( null, moreColors, "Color Chooser", JOptionPane.INFORMATION_MESSAGE );

            }
            else if(e.getSource() == gradient1){
                JOptionPane.showMessageDialog( null, colorChoice1, "Gradient Color 1", JOptionPane.INFORMATION_MESSAGE );
            }
            else if( e.getSource() == gradient2 ){
                JOptionPane.showMessageDialog( null, colorChoice2, "Gradient Color 2", JOptionPane.INFORMATION_MESSAGE );
            }
        }
    }

    //Tracks whether the gradient or filled checkbox is ticked or not
    class CheckBoxListener implements ItemListener{
        @Override 
        public void itemStateChanged( ItemEvent e ) {
            if( e.getSource() == wantFilled){
                if ( wantFilled.isSelected() ) {
                    filled = true;
                } 
                else {
                    filled = false;
                }
                DrawPanel.importFilled( filled);
            }
            else if( e.getSource() == wantGradient){
                if ( wantGradient.isSelected() ) {
                    gradient = true;
                    DrawPanel.importGradient(gradient);
                } 
                else {
                    gradient = false;
                    DrawPanel.importGradient(gradient);
                }
            }
        }
    }

    //Sends an index from the shapeOptions array to DrawPanel to be dranw based on which shape is chosen
    class ChooseShapeListener implements ItemListener{
        @Override 
        public void itemStateChanged( ItemEvent e ) {
            DrawPanel.importShape(shapeChooser.getSelectedIndex() );
            //Passes the index of the shape choice to DrawPanel as the shape will be drawn there depending on the index number
        }
    }

    //Takes the shapes arraylist and backup arraylist from DrawPanel and clears them if clicked
    class ClearCanvas implements ActionListener{
        @Override 
        public void actionPerformed( ActionEvent e ) {
            DrawPanel.setShapes( new ArrayList<Shape>());
            DrawPanel.setSaveShapes( new ArrayList<Shape>());
            mainPanel.update();
        }
    }
    //Deletes the last drawn shape / last object in the shapes arraylist and also saves it to the backup arraylist
    class UndoShape implements ActionListener{
        @Override 
        public void actionPerformed( ActionEvent e ) {
            if( !DrawPanel.getShapes().isEmpty()){
                DrawPanel.undoShape();
                mainPanel.update();
            }
        }
    }

    //Calls the redo method in DrawPanel to add the saved shape from the backup arraylist back into the shapes arraylist
    class RedoShape implements ActionListener{
        @Override 
        public void actionPerformed( ActionEvent e ) {
            if( !DrawPanel.getSavedShapes().isEmpty()){
                DrawPanel.redoShape();
                mainPanel.update();
            }
        }
    }
}