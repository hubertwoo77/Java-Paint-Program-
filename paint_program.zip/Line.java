/**
* Class for drawing lines and free draw option
*
* @author Hubert Woo
* @version July 4 2022
*/
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.GradientPaint;
public class Line extends Shape{
    private static int numLines;
    //Constructor for Line
    public Line( int x1, int y1, int x2, int y2, Color color, boolean gradient, Color gradientColor1, Color gradientColor2){
        super(x1,y1,x2,y2,color, gradient, gradientColor1, gradientColor2);
        numLines++;
    }
    //Draw method for lines and free draw mechanic
    public void draw(Graphics g){
        if( getGradient() == true){
            //Creates a gradient pattern
            Graphics2D gradientTime = (Graphics2D)g;
            GradientPaint twoColors = new GradientPaint( (float) getX1(), (float) getY1(), getGradientColor1(), (float) getX2(), (float) getY2(), getGradientColor2());
            gradientTime.setPaint( twoColors);
            gradientTime.drawLine(getX1(),getY1(),getX2(),getY2());
        }
        else{
            //Normal Line
            g.setColor(getColor());
            g.drawLine(getX1(),getY1(),getX2(),getY2());
        }
        
    }

    //Returns the numer of lines drawn
    public static int getNumLines(){
        return numLines;
    }
}
