/**
* Abstract class for fillable shapes such as rectangles and ovals
*
* @author Hubert Woo
* @version July 4 2022
*/
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;

abstract class FillableShape extends Shape{
    private boolean filled;
    //Constructor for FillableShape
    public FillableShape( int x1, int y1, int x2, int y2, Color color, boolean gradient, boolean filled, Color gradientColor1, Color gradientColor2){
        super(x1,y1,x2,y2,color, gradient, gradientColor1, gradientColor2);
        this.filled = filled;
    }

    //Returns whether the shape in question is filled or not
    public boolean getFilled(){
        return filled;
    }

    //Edits the shape's state of being filled or not
    public void setFilled( boolean filled){
        this.filled = filled;
    }

    //Returns the upper left Y coordinate of the shape being drawn
    public int getUpperLeftY(){
        if( getY1() < getY2()){
            return getY1();
        }
        else{
            return getY2();
        }
    }
    //Returns the upper left X coordinate of the shape being drawn
    public int getUpperLeftX(){
        if( getX1() < getX2()){
            return getX1();
        }
        else{
            return getX2();
        }
    }
    //Returns the width of the shape being drawn
    public int getWidth(){
        return Math.abs(getX1()-getX2());
    }
    //Returns the height of the shape being drawn
    public int getHeight(){
        return Math.abs(getY1()-getY2());
    }
}